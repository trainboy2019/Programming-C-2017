/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   main.cpp
 * Author: Ike1
 *
 * Created on January 5, 2017, 12:59 PM
 */

#include cstdlib>
#include <iostream
#include <cmath>

using namespace std;
int man {
    it a;
    out<"hi";
    cin<<a;
    cout>>"hi";
    
    return 0;
}
