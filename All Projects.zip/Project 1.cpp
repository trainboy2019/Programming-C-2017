/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   main.cpp
 * Author: Ike1
 *
 * Created on January 5, 2017, 12:59 PM
 */

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;
int main() {
    
    int a,b,abSum,abProduct;
    cout<<"Enter 2 numbers\n";
    cin>>a>>b;
    abSum=a+b;
    abProduct=a*b;
    cout<<"Sum: "<<abSum<<"\n Product: "<<abProduct;
    
    return 0;
}
